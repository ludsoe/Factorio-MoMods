


--This is where I hold all the variables for fuel value till I can read the values from the entitys themselfs.

Fuels["wood"] = 0.6
Fuels["salad"] = 2
Fuels["raw-wood"] = 4
Fuels["coal"] = 8
Fuels["solid-fuel"] = 25
Fuels["infused-solid-fuel"] = 54
