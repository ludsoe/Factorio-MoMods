GetTable=function()
	MoGui=MoGui or {}
	return MoGui
end

FuncRegister("Test",function()
end)