if data.XModSupport then
	data.XModData.mofarm = true
end

require("prototypes.plants")
require("prototypes.machines")
