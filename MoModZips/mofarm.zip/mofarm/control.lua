require "util"
require "defines"

MLC = {
	Math=false,
	Timers=true,
	Misc=true,
	Entity=true
}

MoSave = require "mologiccore.base"
local KTE = MoEntity.KeyToEnt
local Random = MoMisc.Random --Localise the psuedo random function.
local Plant = "greenleaf-ore"

local PlanterCost = 500

remote.addinterface("MoFarm", {
	addfarms = function() 
		local Turbines=MoEntity.findentinsquareradius(MoEntity.getplayerpos(),300,"greenleafplanter")
		MoEntity.LoopThis(Turbines,function(ent)
			MoEntity.AddToLoop("Planters",ent)
		end)
	end,
})

MoEntity.SubscribeOnBuilt("greenleafplanter","FarmSpawn",function(entity)
	MoEntity.AddToLoop("Planters",entity)
end)

function PosOrNeg(Seed)
	local X = Random(Seed,1,10)
	if X>=5then
		return -1
	end
	return 1
end

MoTimers.CreateTimer("PlanterThink",1,0,false,function()
	MoEntity.CallLoop("Planters",function(ent)
		local E = KTE(ent.entity)
		if E.valid then
			if E.energy >= PlanterCost then
				local P = E.position
				local V = {x=P.x+Random(P.x,1,4)*PosOrNeg(P.x),y=P.y+Random(P.y,1,4)*PosOrNeg(P.y)}
				local Plants = MoEntity.findentinsquareradius(V,1,Plant) 
				if #Plants <= 0 then
					local NewPlant = game.createentity({name = Plant, position= V})
					NewPlant.amount=Random((V.x+V.y)*0.1,1,3)
					E.energy=E.energy-PlanterCost
				else
					MoEntity.LoopThis(Plants,function(plnt)
						plnt.amount=plnt.amount+Random((V.x+V.y)*0.1,1,3)
					end)
				end
			end
			return true
		end	
		return false
	end)
end)