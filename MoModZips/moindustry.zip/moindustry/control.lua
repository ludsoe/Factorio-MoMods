require "util"
require "defines"

MLC = {
	Math=false,
	Timers=true,
	Misc=false,
	Entity=true,
	Debug=false
}

MoSave = require "mologiccore.base"

