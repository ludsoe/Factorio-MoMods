data.moindustry = true

require("prototypes.robotlogistics")
require("prototypes.extrarobotresearch")
