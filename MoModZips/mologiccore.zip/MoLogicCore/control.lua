MLC = {
	Math=false, --Load the Math Module?
	Timers=false, --Load the Timer Module?
	Misc=false, --Load the Misc Module?
	Entity=false, --Load the entity module?
	Debug=false --Load the debug module?
}

MoSave = require "mologiccore.base"
