data.mocombat = true

MoConfig = MoConfig or {} --Create a empty table to store our config in

require("config")
require("prototypes.damage-type")
require("prototypes.lweps.base")
require("prototypes.defence.base")
require("prototypes.aliens.base")
require("base-edits")
