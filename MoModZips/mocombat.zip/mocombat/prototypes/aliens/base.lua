local M = MoConfig

if M.Spitters then
	require("spitter")
end

if M.Exploders then
	require("exploder")
end